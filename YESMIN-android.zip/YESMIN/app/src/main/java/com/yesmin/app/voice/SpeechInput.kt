package com.yesmin.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** STT wrapper (Android SpeechRecognizer). Replace this class to swap the STT engine. Call from the main thread. */
class SpeechInput(private val ctx: Context, private val l: Listener) {
    interface Listener {
        fun onLevel(v: Float)
        fun onResult(text: String)
        fun onError(code: Int)
    }

    private var rec: SpeechRecognizer? = null

    fun isAvailable() = SpeechRecognizer.isRecognitionAvailable(ctx)

    fun start() {
        stop()
        val r = SpeechRecognizer.createSpeechRecognizer(ctx)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rms: Float) { l.onLevel(((rms + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) { l.onError(error) }
            override fun onResults(b: Bundle?) {
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) l.onError(SpeechRecognizer.ERROR_NO_MATCH) else l.onResult(t)
            }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        r.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, LANGUAGE_TAG)
            .putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName))
    }

    fun stop() { rec?.destroy(); rec = null }

    companion object {
        /** Kannada. Use "en-IN" or "hi-IN" for other languages; support varies by device/Google app. */
        const val LANGUAGE_TAG = "kn-IN"
    }
}
