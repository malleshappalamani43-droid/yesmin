package com.yesmin.app.ui

import android.app.Application
import android.speech.SpeechRecognizer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.yesmin.app.ai.ElevenLabsClient
import com.yesmin.app.ai.GeminiClient
import com.yesmin.app.commands.*
import com.yesmin.app.core.Msg
import com.yesmin.app.core.YesminException
import com.yesmin.app.data.SecureSettings
import com.yesmin.app.memory.MemoryStore
import com.yesmin.app.memory.SqliteMemoryStore
import com.yesmin.app.voice.AudioPlayer
import com.yesmin.app.voice.SpeechInput
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

enum class Status { IDLE, LISTENING, THINKING, SPEAKING }
data class ChatMessage(val fromUser: Boolean, val text: String)

class AssistantViewModel(app: Application) : AndroidViewModel(app), SpeechInput.Listener {
    val settings = SecureSettings(app)
    val memory: MemoryStore = SqliteMemoryStore(app)

    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS).readTimeout(45, TimeUnit.SECONDS).build()
    private val gemini = GeminiClient(settings, http)
    private val voice = ElevenLabsClient(app, settings, http)
    private val player = AudioPlayer()
    private val speech = SpeechInput(app, this)
    private val router = ActionRouter(app, listOf(
        OpenAppHandler(), CallHandler(), WhatsAppHandler(), YouTubeHandler(), MemoryHandler(memory, settings),
        PlannedHandler(ActionType.CAMERA), PlannedHandler(ActionType.IMAGE_ANALYSIS),
        PlannedHandler(ActionType.SYSTEM_ACTION), PlannedHandler(ActionType.SETTINGS)
    ))

    var status by mutableStateOf(Status.IDLE); private set
    var level by mutableFloatStateOf(0f); private set
    var active by mutableStateOf(false); private set          // continuous conversation on/off
    var permissionRequest by mutableStateOf<List<String>>(emptyList()); private set
    val messages = mutableStateListOf<ChatMessage>()
    var assistantName by mutableStateOf(settings.assistantName); private set
    fun saveAssistantName(n: String) {
        val t = n.trim().ifEmpty { "Alexa" }
        settings.assistantName = t; assistantName = t
    }

    private var failures = 0
    private var pending: AssistantReply? = null              // action awaiting yes/no

    // ---- UI entry points ----
    fun onMicPressed() {
        if (active) endConversation() else { active = true; failures = 0; listen() }
    }
    fun onMicDenied() { messages += ChatMessage(false, Msg.MIC) }
    fun onPermissionsResult() { permissionRequest = emptyList() }
    fun stopSpeaking() { if (status == Status.SPEAKING) { player.stop(); afterSpeaking() } }
    fun onAppBackgrounded() { if (active) endConversation() }  // no background listening (no foreground service)

    // ---- listening ----
    private fun listen() {
        if (!speech.isAvailable()) {
            messages += ChatMessage(false, "ಈ ಫೋನ್‌ನಲ್ಲಿ ಸ್ಪೀಚ್ ರೆಕಗ್ನಿಷನ್ ಲಭ್ಯವಿಲ್ಲ.")
            endConversation(); return
        }
        status = Status.LISTENING
        speech.start()
    }
    private fun endConversation() {
        active = false; pending = null
        speech.stop(); player.stop(); status = Status.IDLE; level = 0f
    }
    private fun afterSpeaking() { if (active) listen() else status = Status.IDLE }

    override fun onLevel(v: Float) { level = v }
    override fun onResult(text: String) { failures = 0; handle(text) }
    override fun onError(code: Int) {
        when (code) {
            SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> { messages += ChatMessage(false, Msg.MIC); endConversation() }
            SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> relistenSoon() // silence is normal
            SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER -> {
                messages += ChatMessage(false, Msg.NET); endConversation()
            }
            else -> if (++failures >= 3) {
                messages += ChatMessage(false, "ಸ್ಪೀಚ್ ರೆಕಗ್ನಿಷನ್ ಪದೇ ಪದೇ ವಿಫಲವಾಗ್ತಿದೆ (ಕೋಡ್ $code)."); endConversation()
            } else relistenSoon()
        }
    }
    private fun relistenSoon() {
        viewModelScope.launch { delay(400); if (active && status == Status.LISTENING) listen() }
    }

    // ---- thinking / acting ----
    private fun handle(text: String) {
        messages += ChatMessage(true, text)
        status = Status.THINKING; level = 0f
        viewModelScope.launch {
            try {
                val p = pending
                if (p != null) {
                    pending = null
                    when {
                        isYes(text) -> { runAction(p); return@launch }
                        isNo(text) -> { speak("ಸರಿ, ರದ್ದು ಮಾಡಿದೆ."); return@launch }
                    }
                }
                val mem = if (settings.memoryEnabled) memory.all().map { it.text } else emptyList()
                val reply = gemini.ask(messages.map { it.fromUser to it.text }.takeLast(12), mem)
                when {
                    reply.action == ActionType.CHAT -> speak(reply.speech)
                    router.needsConfirmation(reply.action) -> { pending = reply; speak(reply.speech) }
                    else -> runAction(reply)
                }
            } catch (e: YesminException) {
                speak(e.spoken)
            } catch (e: Exception) {
                if (e is CancellationException) throw e
                speak(Msg.GEMINI_FAIL)
            }
        }
    }

    private suspend fun runAction(r: AssistantReply) {
        val res = router.execute(r.action, r.args)
        if (res.permissions.isNotEmpty()) permissionRequest = res.permissions
        if (res.leavesApp) active = false   // we're leaving the foreground; listening would stop anyway
        speak(res.spoken ?: r.speech)
    }

    private suspend fun speak(text: String) {
        messages += ChatMessage(false, text)
        status = Status.SPEAKING
        try {
            player.play(voice.synthesize(text)) { afterSpeaking() }
        } catch (e: YesminException) {
            if (e.spoken != text) messages += ChatMessage(false, e.spoken)
            afterSpeaking()
        }
    }

    private fun tokens(s: String) = s.lowercase().split(Regex("[^\\p{L}\\p{M}]+")).toSet()
    private fun isYes(s: String) = tokens(s).any { it in YES }
    private fun isNo(s: String) = tokens(s).any { it in NO }

    override fun onCleared() { speech.stop(); player.stop() }

    companion object {
        private val YES = setOf("yes", "yeah", "yep", "ha", "haan", "haa", "ok", "okay", "sure", "confirm", "sari", "houdu", "hau", "ಹೌದು", "ಹಾ", "ಸರಿ", "ಆಯ್ತು", "ಓಕೆ", "हाँ", "हां")
        private val NO = setOf("no", "nahi", "nope", "illa", "beda", "cancel", "stop", "ಇಲ್ಲ", "ಬೇಡ", "ಬೇಡಾ", "नहीं")
    }
}
