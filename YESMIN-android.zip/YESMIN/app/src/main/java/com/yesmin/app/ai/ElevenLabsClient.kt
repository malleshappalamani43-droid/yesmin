package com.yesmin.app.ai

import android.content.Context
import android.net.Uri
import com.yesmin.app.core.Msg
import com.yesmin.app.core.YesminException
import com.yesmin.app.data.SecureSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException

class ElevenLabsClient(private val ctx: Context, private val settings: SecureSettings, private val http: OkHttpClient) {

    /** Returns a temp mp3 file; the caller (AudioPlayer) deletes it after playback. */
    suspend fun synthesize(text: String): File = withContext(Dispatchers.IO) {
        val key = settings.elevenKey
        val voice = settings.elevenVoiceId
        if (key.isBlank() || voice.isBlank()) throw YesminException(Msg.VOICE_KEY)

        val body = JSONObject().put("text", text).put("model_id", "eleven_v3")
        val req = Request.Builder()
            .url("https://api.elevenlabs.io/v1/text-to-speech/${Uri.encode(voice)}")
            .header("xi-api-key", key)
            .header("Accept", "audio/mpeg")
            .post(body.toString().toRequestBody("application/json".toMediaType()))
            .build()

        val bytes = try {
            http.newCall(req).execute().use { r ->
                when {
                    r.code == 401 -> throw YesminException(Msg.VOICE_BAD_KEY)
                    r.code == 402 || r.code == 429 -> throw YesminException(Msg.VOICE_QUOTA)
                    !r.isSuccessful -> throw YesminException(Msg.VOICE_FAIL)
                    else -> r.body?.bytes() ?: ByteArray(0)
                }
            }
        } catch (e: IOException) { throw YesminException(Msg.NET, e) }

        if (bytes.isEmpty()) throw YesminException(Msg.VOICE_FAIL)
        File.createTempFile("tts", ".mp3", ctx.cacheDir).also { it.writeBytes(bytes) }
    }
}
