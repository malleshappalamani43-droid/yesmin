package com.yesmin.app.vision

import android.graphics.Bitmap

/**
 * PLANNED, NOT IMPLEMENTED. Contract for photo analysis and camera vision.
 * Plan: send the Bitmap as inline_data (base64 JPEG) to Gemini generateContent,
 * add CAMERA permission + CameraX preview, then register an ActionHandler for CAMERA / IMAGE_ANALYSIS.
 */
interface VisionAnalyzer {
    suspend fun analyze(image: Bitmap, question: String): String
}
