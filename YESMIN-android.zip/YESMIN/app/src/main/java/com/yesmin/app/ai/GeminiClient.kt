package com.yesmin.app.ai

import com.yesmin.app.commands.ActionType
import com.yesmin.app.commands.AssistantReply
import com.yesmin.app.core.Msg
import com.yesmin.app.core.YesminException
import com.yesmin.app.data.SecureSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException

class GeminiClient(private val settings: SecureSettings, private val http: OkHttpClient) {

    /** history: (fromUser, text) pairs, newest last. */
    suspend fun ask(history: List<Pair<Boolean, String>>, memories: List<String>): AssistantReply =
        withContext(Dispatchers.IO) {
            val key = settings.geminiKey
            if (key.isBlank()) throw YesminException(Msg.GEMINI_KEY)

            val contents = JSONArray()
            history.dropWhile { !it.first }.forEach { (fromUser, text) ->
                contents.put(JSONObject()
                    .put("role", if (fromUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text))))
            }
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts",
                    JSONArray().put(JSONObject().put("text", systemPrompt(memories)))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("responseMimeType", "application/json"))

            val req = Request.Builder().url(URL)
                .header("x-goog-api-key", key)   // header, not URL, so it never lands in logs
                .post(body.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val (code, raw) = try {
                http.newCall(req).execute().use { it.code to it.body?.string().orEmpty() }
            } catch (e: IOException) { throw YesminException(Msg.NET, e) }

            if (code !in 200..299) {
                if (code == 401 || code == 403 || (code == 400 && raw.contains("API key", true)))
                    throw YesminException(Msg.GEMINI_BAD_KEY)
                throw YesminException(Msg.GEMINI_FAIL)
            }
            val text = try {
                JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")
                    ?.optJSONArray("parts")?.optJSONObject(0)?.optString("text")
            } catch (e: JSONException) { null }
            if (text.isNullOrBlank()) throw YesminException(Msg.GEMINI_FAIL)
            parse(text)
        }

    private fun parse(text: String): AssistantReply = try {
        val o = JSONObject(text)
        val action = runCatching { ActionType.valueOf(o.optString("action", "CHAT").uppercase()) }
            .getOrDefault(ActionType.CHAT)
        val speech = o.optString("speech").trim()
        if (speech.isEmpty()) throw YesminException(Msg.GEMINI_FAIL)
        val args = mutableMapOf<String, String>()
        o.optJSONObject("args")?.let { a -> a.keys().forEach { k -> args[k] = a.optString(k) } }
        AssistantReply(action, speech, args)
    } catch (e: JSONException) {
        AssistantReply(ActionType.CHAT, text.trim(), emptyMap())
    }

    private fun systemPrompt(memories: List<String>) = """
You are YESMIN, a JARVIS-style voice assistant. Reply in the language and style the user speaks (Kannada, Hindi, English or a mix; Roman script is fine). Keep spoken replies short and natural. No markdown, no emojis.
Respond ONLY with JSON: {"action": "...", "speech": "...", "args": {...}}
Actions:
- CHAT: normal conversation (default).
- OPEN_APP: args {"app_name"}.
- CALL_CONTACT: args {"contact"}. "speech" must ask for confirmation, e.g. "Calling Appa. Confirm?"
- SEND_MESSAGE (WhatsApp): args {"contact","message"}; message is the exact text, in first person as the user. "speech" must ask for confirmation.
- PLAY_YOUTUBE: args {"query"} (search text only).
- MEMORY: args {"text"}; only when the user asks you to remember something.
- CAMERA, IMAGE_ANALYSIS, SYSTEM_ACTION: not available yet; use the action if requested and say so briefly.
Known facts about the user: ${if (memories.isEmpty()) "none" else memories.joinToString("; ")}
""".trimIndent()

    companion object {
        private const val URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
    }
}
