package com.yesmin.app.commands

import android.content.Context

enum class ActionType { CHAT, OPEN_APP, CALL_CONTACT, SEND_MESSAGE, PLAY_YOUTUBE, CAMERA, IMAGE_ANALYSIS, MEMORY, SETTINGS, SYSTEM_ACTION }

/** What Gemini returns: the detected action, what to say, and string arguments. */
data class AssistantReply(val action: ActionType, val speech: String, val args: Map<String, String>)

data class ActionResult(
    val ok: Boolean,
    val spoken: String? = null,          // null = speak Gemini's own text
    val permissions: List<String> = emptyList(), // runtime permissions the UI should request
    val leavesApp: Boolean = false       // action moved the user to another app
)

/** Add a new voice command by implementing this and registering it in AssistantViewModel. */
interface ActionHandler {
    val type: ActionType
    val needsConfirmation: Boolean get() = false
    suspend fun execute(ctx: Context, args: Map<String, String>): ActionResult
}

class ActionRouter(private val ctx: Context, handlers: List<ActionHandler>) {
    private val map = handlers.associateBy { it.type }
    fun needsConfirmation(t: ActionType) = map[t]?.needsConfirmation == true
    suspend fun execute(t: ActionType, args: Map<String, String>): ActionResult =
        map[t]?.execute(ctx, args) ?: ActionResult(false, "ಸರ್, ಈ ಫೀಚರ್ ಇನ್ನೂ ಲಭ್ಯವಿಲ್ಲ.")
}
