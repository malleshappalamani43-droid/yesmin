package com.yesmin.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.sin

@Composable
fun AiCore(status: Status, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "core")
    val rot by t.animateFloat(0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "rot")
    val pulse by t.animateFloat(0.92f, 1.08f,
        infiniteRepeatable(tween(if (status == Status.SPEAKING) 600 else 1600), RepeatMode.Reverse), label = "pulse")
    val color by animateColorAsState(when (status) {
        Status.LISTENING -> Cyan; Status.THINKING -> Violet; Status.SPEAKING -> Magenta; Status.IDLE -> Dim
    }, label = "color")
    Canvas(modifier) {
        val c = center; val r = size.minDimension / 2
        drawCircle(Brush.radialGradient(listOf(color.copy(.5f), color.copy(.1f), Color.Transparent), c, r), r)
        drawCircle(color, r * 0.42f * pulse, c, style = Stroke(3.dp.toPx()))
        drawCircle(Brush.radialGradient(listOf(Color.White, color), c, r * 0.3f * pulse), r * 0.3f * pulse, c)
        fun ring(rad: Float, a: Float, sweep: Float, w: Float) =
            drawArc(color, a, sweep, false, Offset(c.x - rad, c.y - rad), Size(rad * 2, rad * 2),
                style = Stroke(w, cap = StrokeCap.Round))
        rotate(rot, c) { ring(r * 0.62f, 0f, 90f, 4.dp.toPx()); ring(r * 0.62f, 180f, 90f, 4.dp.toPx()) }
        rotate(-rot * 1.5f, c) { ring(r * 0.82f, 30f, 40f, 2.dp.toPx()); ring(r * 0.82f, 150f, 40f, 2.dp.toPx()); ring(r * 0.82f, 270f, 40f, 2.dp.toPx()) }
    }
}

@Composable
fun Waveform(status: Status, level: Float, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "wave")
    val phase by t.animateFloat(0f, (2 * PI).toFloat(), infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "p")
    val target = when (status) {
        Status.LISTENING -> 0.15f + level * 0.85f; Status.SPEAKING -> 0.65f
        Status.THINKING -> 0.2f; Status.IDLE -> 0.05f
    }
    val amp by animateFloatAsState(target, label = "amp")
    val color = when (status) { Status.SPEAKING -> Magenta; Status.THINKING -> Violet; else -> Cyan }
    Canvas(modifier) {
        val n = 32; val gap = size.width / n
        for (i in 0 until n) {
            val h = size.height * amp * (0.35f + 0.65f * abs(sin(phase + i * 0.45f)))
            val x = i * gap + gap / 2
            drawLine(color, Offset(x, size.height / 2 - h / 2), Offset(x, size.height / 2 + h / 2),
                strokeWidth = gap * 0.5f, cap = StrokeCap.Round)
        }
    }
}
