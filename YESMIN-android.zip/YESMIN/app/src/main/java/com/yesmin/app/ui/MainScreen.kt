package com.yesmin.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

@Composable
fun MainScreen(vm: AssistantViewModel, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.onMicPressed() else vm.onMicDenied()
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.onPermissionsResult()
    }
    LaunchedEffect(vm.permissionRequest) {
        if (vm.permissionRequest.isNotEmpty()) permLauncher.launch(vm.permissionRequest.toTypedArray())
    }
    val listState = rememberLazyListState()
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.lastIndex)
    }

    Column(Modifier.fillMaxSize().background(Bg).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
            Text(vm.assistantName.uppercase(), color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
            IconButton(onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Cyan) }
        }
        AiCore(vm.status, Modifier.size(200.dp))
        Text(when (vm.status) {
            Status.IDLE -> "IDLE"; Status.LISTENING -> "LISTENING"
            Status.THINKING -> "THINKING"; Status.SPEAKING -> "SPEAKING"
        }, color = Cyan, letterSpacing = 4.sp, fontSize = 13.sp)
        Waveform(vm.status, vm.level, Modifier.fillMaxWidth().height(44.dp).padding(vertical = 6.dp))

        LazyColumn(Modifier.weight(1f).fillMaxWidth(), state = listState, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(vm.messages.size) { i ->
                val m = vm.messages[i]
                Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
                    Text(m.text, color = Color.White, fontSize = 15.sp, modifier = Modifier
                        .widthIn(max = 300.dp)
                        .background(Panel, RoundedCornerShape(14.dp))
                        .border(1.dp, (if (m.fromUser) Violet else Cyan).copy(alpha = .5f), RoundedCornerShape(14.dp))
                        .padding(12.dp))
                }
            }
        }

        Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.CenterVertically) {
            FilledIconButton(
                onClick = {
                    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                        vm.onMicPressed() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                },
                modifier = Modifier.size(72.dp),
                colors = IconButtonDefaults.filledIconButtonColors(containerColor = if (vm.active) Magenta else Cyan, contentColor = Color.Black)
            ) { Icon(if (vm.active) Icons.Default.MicOff else Icons.Default.Mic, if (vm.active) "End conversation" else "Start conversation") }
            OutlinedIconButton(onClick = vm::stopSpeaking, enabled = vm.status == Status.SPEAKING, modifier = Modifier.size(56.dp)) {
                Icon(Icons.Default.Stop, "Stop speaking", tint = if (vm.status == Status.SPEAKING) Magenta else Dim)
            }
        }
    }
}
