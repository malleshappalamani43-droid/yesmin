package com.yesmin.app.commands

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import com.yesmin.app.contacts.ContactsRepository
import com.yesmin.app.data.SecureSettings
import com.yesmin.app.memory.MemoryStore

private fun Context.granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
private fun Intent.newTask() = apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

class OpenAppHandler : ActionHandler {
    override val type = ActionType.OPEN_APP
    override suspend fun execute(ctx: Context, args: Map<String, String>): ActionResult {
        val name = args["app_name"].orEmpty().trim()
        if (name.isEmpty()) return ActionResult(false, "ಯಾವ ಆ್ಯಪ್ ತೆರೆಯಬೇಕು?")
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val match = apps.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: apps.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
        val intent = match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
            ?: return ActionResult(false, "ಸರ್, $name ಆ್ಯಪ್ ಸಿಗಲಿಲ್ಲ.")
        ctx.startActivity(intent.newTask())
        return ActionResult(true, leavesApp = true)
    }
}

class CallHandler : ActionHandler {
    override val type = ActionType.CALL_CONTACT
    override val needsConfirmation = true
    override suspend fun execute(ctx: Context, args: Map<String, String>): ActionResult {
        val name = args["contact"].orEmpty().trim()
        if (name.isEmpty()) return ActionResult(false, "ಯಾರಿಗೆ ಕಾಲ್ ಮಾಡಬೇಕು?")
        if (!ctx.granted(Manifest.permission.READ_CONTACTS))
            return ActionResult(false, "ಕಾಂಟಾಕ್ಟ್ಸ್ ಅನುಮತಿ ಬೇಕು. ಅನುಮತಿ ಕೊಟ್ಟು ಮತ್ತೆ ಹೇಳಿ.",
                permissions = listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
        val c = ContactsRepository(ctx).find(name)
            ?: return ActionResult(false, "ಸರ್, ಕಾಂಟಾಕ್ಟ್ಸ್‌ನಲ್ಲಿ $name ಸಿಗಲಿಲ್ಲ.")
        val uri = Uri.parse("tel:" + Uri.encode(c.number))
        return if (ctx.granted(Manifest.permission.CALL_PHONE)) {
            ctx.startActivity(Intent(Intent.ACTION_CALL, uri).newTask()); ActionResult(true)
        } else {
            // Without CALL_PHONE we can only open the dialer; the user presses call.
            ctx.startActivity(Intent(Intent.ACTION_DIAL, uri).newTask())
            ActionResult(true, "ಡಯಲರ್ ತೆರೆದಿದೆ, ಕಾಲ್ ಬಟನ್ ಒತ್ತಿ.", leavesApp = true)
        }
    }
}

/** WhatsApp has no official silent-send API for normal apps: this opens a chat with the text prefilled; the user taps Send. */
class WhatsAppHandler : ActionHandler {
    override val type = ActionType.SEND_MESSAGE
    override val needsConfirmation = true
    override suspend fun execute(ctx: Context, args: Map<String, String>): ActionResult {
        val name = args["contact"].orEmpty().trim()
        val msg = args["message"].orEmpty().trim()
        if (name.isEmpty() || msg.isEmpty()) return ActionResult(false, "ಯಾರಿಗೆ, ಏನು ಮೆಸೇಜ್ ಕಳಿಸಬೇಕು?")
        if (!ctx.granted(Manifest.permission.READ_CONTACTS))
            return ActionResult(false, "ಕಾಂಟಾಕ್ಟ್ಸ್ ಅನುಮತಿ ಬೇಕು. ಅನುಮತಿ ಕೊಟ್ಟು ಮತ್ತೆ ಹೇಳಿ.",
                permissions = listOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
        val c = ContactsRepository(ctx).find(name)
            ?: return ActionResult(false, "ಸರ್, ಕಾಂಟಾಕ್ಟ್ಸ್‌ನಲ್ಲಿ $name ಸಿಗಲಿಲ್ಲ.")
        var digits = c.number.filter { it.isDigit() }
        if (digits.length == 10 && !c.number.trim().startsWith("+")) digits = DEFAULT_COUNTRY_CODE + digits
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$digits?text=" + Uri.encode(msg)))
            .setPackage("com.whatsapp").newTask()
        return try {
            ctx.startActivity(intent)
            ActionResult(true, "WhatsApp ನಲ್ಲಿ ${c.name} ಅವರಿಗೆ ಮೆಸೇಜ್ ರೆಡಿ ಇದೆ. ಸೆಂಡ್ ಒತ್ತಿ.", leavesApp = true)
        } catch (e: ActivityNotFoundException) {
            ActionResult(false, "ಸರ್, WhatsApp ಇನ್‌ಸ್ಟಾಲ್ ಆಗಿಲ್ಲ.")
        }
    }
    companion object { const val DEFAULT_COUNTRY_CODE = "91" } // applied only to 10-digit numbers without "+"
}

/** Opens YouTube search results (does not auto-play). */
class YouTubeHandler : ActionHandler {
    override val type = ActionType.PLAY_YOUTUBE
    override suspend fun execute(ctx: Context, args: Map<String, String>): ActionResult {
        val q = args["query"].orEmpty().trim()
        if (q.isEmpty()) return ActionResult(false, "YouTube ನಲ್ಲಿ ಏನು ಹುಡುಕಬೇಕು?")
        try {
            ctx.startActivity(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube")
                .putExtra("query", q).newTask())
        } catch (e: ActivityNotFoundException) {
            ctx.startActivity(Intent(Intent.ACTION_VIEW,
                Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))).newTask())
        }
        return ActionResult(true, leavesApp = true)
    }
}

class MemoryHandler(private val store: MemoryStore, private val settings: SecureSettings) : ActionHandler {
    override val type = ActionType.MEMORY
    override suspend fun execute(ctx: Context, args: Map<String, String>): ActionResult {
        if (!settings.memoryEnabled) return ActionResult(false, "ಮೆಮೊರಿ Settings ನಲ್ಲಿ ಆಫ್ ಆಗಿದೆ.")
        val t = args["text"].orEmpty().trim()
        if (t.isEmpty()) return ActionResult(false, "ಏನು ನೆನಪಿಟ್ಟುಕೊಳ್ಳಬೇಕು?")
        store.add(t); return ActionResult(true)
    }
}

/** Honest placeholder for features that are designed but not built yet. */
class PlannedHandler(override val type: ActionType) : ActionHandler {
    override suspend fun execute(ctx: Context, args: Map<String, String>) =
        ActionResult(false, "ಸರ್, ಈ ಫೀಚರ್ ಇನ್ನೂ YESMIN ನಲ್ಲಿ ಲಭ್ಯವಿಲ್ಲ.")
}
