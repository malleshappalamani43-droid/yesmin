package com.yesmin.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun Section(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).background(Panel).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, color = Cyan, fontSize = 16.sp, letterSpacing = 2.sp)
        content()
    }
}

@Composable
fun SettingsScreen(vm: AssistantViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val s = vm.settings
    var elKey by remember { mutableStateOf(s.elevenKey) }
    var voiceId by remember { mutableStateOf(s.elevenVoiceId) }
    var gKey by remember { mutableStateOf(s.geminiKey) }
    var memOn by remember { mutableStateOf(s.memoryEnabled) }
    var items by remember { mutableStateOf(vm.memory.all()) }
    fun toast(t: String) = Toast.makeText(ctx, t, Toast.LENGTH_SHORT).show()

    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState()).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Cyan) }
            Text("SETTINGS", color = Cyan, fontSize = 20.sp, letterSpacing = 4.sp)
        }
        Section("ELEVENLABS") {
            OutlinedTextField(elKey, { elKey = it }, label = { Text("API key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(voiceId, { voiceId = it }, label = { Text("Voice ID") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Button({ s.elevenKey = elKey.trim(); s.elevenVoiceId = voiceId.trim(); toast("ElevenLabs saved") }) { Text("Save") }
        }
        Section("GEMINI") {
            OutlinedTextField(gKey, { gKey = it }, label = { Text("API key") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Button({ s.geminiKey = gKey.trim(); toast("Gemini saved") }) { Text("Save") }
        }
        Section("MEMORY") {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text("Enable memory")
                Switch(memOn, { memOn = it; s.memoryEnabled = it })
            }
            if (items.isEmpty()) Text("Nothing saved.", color = Dim)
            items.forEach { m ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(m.text, Modifier.weight(1f))
                    IconButton({ vm.memory.delete(m.id); items = vm.memory.all() }) { Icon(Icons.Default.Delete, "Delete", tint = Magenta) }
                }
            }
            if (items.isNotEmpty()) TextButton({ vm.memory.clear(); items = emptyList() }) { Text("Clear all memory", color = Magenta) }
        }
    }
}
