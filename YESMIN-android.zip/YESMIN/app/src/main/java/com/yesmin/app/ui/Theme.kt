package com.yesmin.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF05080F)
val Panel = Color(0xFF0B1220)
val Cyan = Color(0xFF00E5FF)
val Violet = Color(0xFF7C4DFF)
val Magenta = Color(0xFFFF2E93)
val Dim = Color(0xFF3A5068)

@Composable
fun YesminTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Cyan, onPrimary = Color.Black, background = Bg,
        surface = Panel, onSurface = Color.White, onBackground = Color.White),
    content = content
)
