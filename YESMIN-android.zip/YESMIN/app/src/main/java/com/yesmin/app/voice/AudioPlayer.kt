package com.yesmin.app.voice

import android.media.MediaPlayer
import java.io.File

class AudioPlayer {
    private var mp: MediaPlayer? = null
    private var file: File? = null

    fun play(f: File, onDone: () -> Unit) {
        stop()
        file = f
        try {
            mp = MediaPlayer().apply {
                setDataSource(f.absolutePath)
                setOnPreparedListener { it.start() }
                setOnCompletionListener { finish(onDone) }
                setOnErrorListener { _, _, _ -> finish(onDone); true }
                prepareAsync()
            }
        } catch (e: Exception) { finish(onDone) }
    }

    fun stop() {
        mp?.setOnCompletionListener(null); mp?.setOnErrorListener(null)
        finish(null)
    }

    private fun finish(cb: (() -> Unit)?) {
        val m = mp; mp = null
        runCatching { m?.release() }
        file?.delete(); file = null
        cb?.invoke()
    }
}
