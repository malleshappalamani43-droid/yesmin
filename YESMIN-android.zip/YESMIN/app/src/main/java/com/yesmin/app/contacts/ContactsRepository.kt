package com.yesmin.app.contacts

import android.content.Context
import android.provider.ContactsContract.CommonDataKinds.Phone

data class Contact(val name: String, val number: String)

class ContactsRepository(private val ctx: Context) {
    /** Requires READ_CONTACTS granted. Returns the first contact whose name contains [query]. */
    fun find(query: String): Contact? {
        ctx.contentResolver.query(
            Phone.CONTENT_URI, arrayOf(Phone.DISPLAY_NAME, Phone.NUMBER),
            "${Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$query%"), "${Phone.DISPLAY_NAME} ASC"
        )?.use { c -> if (c.moveToFirst()) return Contact(c.getString(0), c.getString(1)) }
        return null
    }
}
