package com.yesmin.app.data

import android.content.Context
import androidx.core.content.edit
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** Keys live only in encrypted prefs (Android Keystore-backed). Gemini and ElevenLabs are stored under separate keys. */
class SecureSettings(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context, "yesmin_secure",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    var geminiKey: String
        get() = prefs.getString("gemini_key", "").orEmpty()
        set(v) = prefs.edit { putString("gemini_key", v) }
    var elevenKey: String
        get() = prefs.getString("eleven_key", "").orEmpty()
        set(v) = prefs.edit { putString("eleven_key", v) }
    var elevenVoiceId: String
        get() = prefs.getString("eleven_voice", "").orEmpty()
        set(v) = prefs.edit { putString("eleven_voice", v) }
    var assistantName: String
        get() = prefs.getString("assistant_name", "Alexa").orEmpty().ifBlank { "Alexa" }
        set(v) = prefs.edit { putString("assistant_name", v) }
    var memoryEnabled: Boolean
        get() = prefs.getBoolean("memory_on", true)
        set(v) = prefs.edit { putBoolean("memory_on", v) }
}
