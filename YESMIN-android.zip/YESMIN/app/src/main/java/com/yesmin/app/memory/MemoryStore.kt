package com.yesmin.app.memory

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class MemoryItem(val id: Long, val text: String, val createdAt: Long)

/** Swap the implementation (Room, cloud) without touching callers. */
interface MemoryStore {
    fun add(text: String)
    fun all(): List<MemoryItem>
    fun delete(id: Long)
    fun clear()
}

class SqliteMemoryStore(ctx: Context) : SQLiteOpenHelper(ctx, "yesmin_memory.db", null, 1), MemoryStore {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE memory(id INTEGER PRIMARY KEY AUTOINCREMENT, text TEXT NOT NULL, created_at INTEGER NOT NULL)")
    }
    override fun onUpgrade(db: SQLiteDatabase, o: Int, n: Int) {}
    override fun add(text: String) {
        writableDatabase.insert("memory", null, ContentValues().apply {
            put("text", text); put("created_at", System.currentTimeMillis())
        })
    }
    override fun all(): List<MemoryItem> {
        val out = mutableListOf<MemoryItem>()
        readableDatabase.query("memory", null, null, null, null, null, "id DESC").use { c ->
            while (c.moveToNext()) out.add(MemoryItem(
                c.getLong(c.getColumnIndexOrThrow("id")),
                c.getString(c.getColumnIndexOrThrow("text")),
                c.getLong(c.getColumnIndexOrThrow("created_at"))))
        }
        return out
    }
    override fun delete(id: Long) { writableDatabase.delete("memory", "id=?", arrayOf(id.toString())) }
    override fun clear() { writableDatabase.delete("memory", null, null) }
}
