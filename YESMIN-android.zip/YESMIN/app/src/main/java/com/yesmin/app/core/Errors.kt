package com.yesmin.app.core

/** An error whose [spoken] text is safe to show/speak to the user. Never contains secrets. */
class YesminException(val spoken: String, cause: Throwable? = null) : Exception(spoken, cause)

object Msg {
    const val GEMINI_FAIL = "ಸರ್, Gemini ನಿಂದ ಉತ್ತರ ಬರ್ತಿಲ್ಲ."
    const val GEMINI_KEY = "ಸರ್, Settings ನಲ್ಲಿ Gemini API key ಸೇವ್ ಮಾಡಿ."
    const val GEMINI_BAD_KEY = "ಸರ್, Gemini API key ಸರಿಯಿಲ್ಲ."
    const val VOICE_FAIL = "ಸರ್, ವಾಯ್ಸ್ ಸೇವೆ ಸದ್ಯಕ್ಕೆ ಲಭ್ಯವಿಲ್ಲ."
    const val VOICE_KEY = "ಸರ್, Settings ನಲ್ಲಿ ElevenLabs API key ಮತ್ತು Voice ID ಸೇವ್ ಮಾಡಿ."
    const val VOICE_BAD_KEY = "ಸರ್, ElevenLabs API key ಸರಿಯಿಲ್ಲ."
    const val VOICE_QUOTA = "ಸರ್, ElevenLabs ಕ್ವೋಟಾ ಮುಗಿದಿದೆ."
    const val MIC = "ಮೈಕ್ರೊಫೋನ್ ಅನುಮತಿ ಬೇಕು."
    const val NET = "ಇಂಟರ್ನೆಟ್ ಸಂಪರ್ಕ ಪರಿಶೀಲಿಸಿ."
}
