package com.yesmin.app.core

/** An error whose [spoken] text is safe to show/speak to the user. Never contains secrets. */
class YesminException(val spoken: String, cause: Throwable? = null) : Exception(spoken, cause)

object Msg {
    const val GEMINI_FAIL = "Sir, Gemini se response nahi aa raha."
    const val GEMINI_KEY = "Sir, Gemini API key Settings mein save kijiye."
    const val GEMINI_BAD_KEY = "Sir, Gemini API key invalid hai."
    const val VOICE_FAIL = "Sir, voice service temporarily unavailable hai."
    const val VOICE_KEY = "Sir, ElevenLabs API key aur Voice ID Settings mein save kijiye."
    const val VOICE_BAD_KEY = "Sir, ElevenLabs API key invalid hai."
    const val VOICE_QUOTA = "Sir, ElevenLabs quota khatam ho gaya hai."
    const val MIC = "Microphone permission required hai."
    const val NET = "Internet connection check kijiye."
}
