# YESMIN (Android, Kotlin + Jetpack Compose)

Open the `YESMIN` folder in Android Studio (Koala+), let Gradle sync, run on a real device (min SDK 26).
For command-line builds run `gradle wrapper` once. In Settings enter your Gemini key, ElevenLabs key and Voice ID.

## Works now
- Continuous loop: mic -> Android SpeechRecognizer -> Gemini (intent + reply as JSON) -> ElevenLabs TTS -> listens again. Stop button, status, waveform, AI core.
- Keys in EncryptedSharedPreferences (Gemini and ElevenLabs stored separately), sent only in HTTP headers, never logged.
- Memory (SQLite behind `MemoryStore`): saved when you ask YESMIN to remember; view/delete/clear/enable in Settings.
- Actions (`commands/Handlers.kt`): OPEN_APP, CALL_CONTACT, SEND_MESSAGE (WhatsApp), PLAY_YOUTUBE, MEMORY. Calls and messages ask for yes/no first.
- Error messages from your spec for Gemini, ElevenLabs, mic, network; bad key and quota are handled.

## Limits (by design, no workarounds)
- WhatsApp: opens the chat with text prefilled; you tap Send (no official silent-send API). 10-digit numbers get +91 (`WhatsAppHandler.DEFAULT_COUNTRY_CODE`).
- YouTube: opens search results; it does not auto-play.
- Calls: ACTION_CALL if CALL_PHONE is granted, otherwise opens the dialer.
- Listening only works while the app is on screen (no foreground service yet), and stops when another app is opened.
- Chat history is not persisted yet; only explicit memories are.
- STT language is `SpeechInput.LANGUAGE_TAG` ("en-IN"); Kannada ("kn-IN") support depends on the device.

## Not implemented (architecture only)
- Camera vision / photo analysis: `vision/VisionAnalyzer.kt` interface + PLANNED action types.
- Incoming call assistant: needs READ_PHONE_STATE / call-screening role and ANSWER_PHONE_CALLS (TelecomManager.acceptRingingCall), plus a foreground service; Android also restricts mic use during calls. Separate milestone.
- Live Call Mode: the same pipeline with streaming STT/TTS; swap `SpeechInput`, `GeminiClient`, `ElevenLabsClient`.

Not compiled or run in the authoring environment: expect to fix small build issues on first sync.
